# 🔥 Free Fire Tournament Website

এটি একটি সহজ **Free Fire Tournament Website Template**।  
GitHub Pages ব্যবহার করে একদম ফ্রি তে ওয়েবসাইট চালু করতে পারবেন।

## 🚀 Features
- Tournament Details
- Prize Pool
- Points Table
- Payment Info (Bkash/Nagad)
- Registration Form (Name, Email, Team, Transaction ID)

## 📂 কিভাবে ব্যবহার করবেন
1. এই রিপোজিটরি **Use this template** করে নতুন রিপোজিটরি বানান।
2. `index.html` ফাইল 그대로 রাখুন অথবা নিজের মতো এডিট করুন।
3. GitHub রিপোজিটরিতে গিয়ে:
   - **Settings → Pages → Branch: main / root → Save**  
4. আপনার ওয়েবসাইট হবে:  
   ```
   https://your-username.github.io/your-repo-name/
   ```

## 🏆 Demo
এই টেমপ্লেট থেকে বানানো ওয়েবসাইট এভাবেই দেখাবে:  
- Prize Money Section  
- Tournament Points Table  
- Payment Info  
- Registration Form  

---
© 2025 Free Fire Tournament Template
